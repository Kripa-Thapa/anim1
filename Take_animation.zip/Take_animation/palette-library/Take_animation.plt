ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d5a568b95f015e1   0   0   0 255
Solid    White                      0x0d5a568b95f015e4 255 255 255 255
Solid    Red                        0x0d5a568b95f015e7 255   0   0 255
Solid    Green                      0x0d5a568b95f015ea   0 255   0 255
Solid    Blue                       0x0d5a568b95f015ed   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
