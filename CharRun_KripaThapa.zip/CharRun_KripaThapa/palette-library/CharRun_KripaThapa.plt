ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d51788be32016ed   0   0   0 255
Solid    White                      0x0d51788be32016f0 255 255 255 255
Solid    Red                        0x0d51788be32016f3 255   0   0 255
Solid    Green                      0x0d51788be32016f6   0 255   0 255
Solid    Blue                       0x0d51788be32016f9   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
