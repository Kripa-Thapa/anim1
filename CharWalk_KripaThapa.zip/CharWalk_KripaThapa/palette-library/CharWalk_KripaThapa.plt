ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d5177a6ad601791   0   0   0 255
Solid    White                      0x0d5177a6ad601794 255 255 255 255
Solid    Red                        0x0d5177a6ad601797 255   0   0 255
Solid    Green                      0x0d5177a6ad60179a   0 255   0 255
Solid    Blue                       0x0d5177a6ad60179d   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
