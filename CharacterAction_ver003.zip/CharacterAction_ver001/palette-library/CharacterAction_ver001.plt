ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d494e070ab0152d   0   0   0 255
Solid    White                      0x0d494e070ab01530 255 255 255 255
Solid    Red                        0x0d494e070ab01533 255   0   0 255
Solid    Green                      0x0d494e070ab01536   0 255   0 255
Solid    Blue                       0x0d494e070ab01539   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
