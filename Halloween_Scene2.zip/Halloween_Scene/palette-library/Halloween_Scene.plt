ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d56b7a61960164b   0   0   0 255
Solid    White                      0x0d56b7a61960164e 255 255 255 255
Solid    Red                        0x0d56b7a619601651 255   0   0 255
Solid    Green                      0x0d56b7a619601654   0 255   0 255
Solid    Blue                       0x0d56b7a619601657   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
