ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d47fe31a0b016ba   0   0   0 255
Solid    White                      0x0d47fe31a0b016bd 255 255 255 255
Solid    Red                        0x0d47fe31a0b016c0 255   0   0 255
Solid    Green                      0x0d47fe31a0b016c3   0 255   0 255
Solid    Blue                       0x0d47fe31a0b016c6   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
